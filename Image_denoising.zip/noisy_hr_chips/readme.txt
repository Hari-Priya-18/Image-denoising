This folder contains noisy images for Multispectral (MX) and PAN (pan) data.
for mx each image has 4 bands (blue (1), green(2), red(3) and NIR (4)).
All images are unsigned short int (2 bytes), 512 x 512 (width x height).

MX images should be stacked in order to be visualized correctly.